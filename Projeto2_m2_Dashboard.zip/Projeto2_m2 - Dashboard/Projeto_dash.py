import streamlit as st # version: 0.62
import pandas as pd
import numpy as np
import cufflinks as cf
import plotly.express as px

df_short = pd.read_csv('./netflix_trat.csv')

st.title('Estatística de audiência da netflix no Reino Unido:popcorn:')

st.markdown('Esse dataset foi retirado do https://www.kaggle.com/vodclickstream/netflix-audience-behaviour-uk-movies')

st.subheader('Gráficos de 2017 - 2019')

# Top 10 filmes 2017-2019
df_best = df_short.groupby('title').count().reset_index() 
df_best.rename(columns={'datetime' : 'quantity'}, inplace=True)
df_best.drop(columns=['genres', 'date', 'time', 'year'], inplace=True)

df_best['genres'] = df_short['genres']

df_best.sort_values('quantity', ascending=False, inplace=True)

fig = px.bar(
        df_best, 
        x=df_best.title.head(10),
        y=df_best.quantity.head(10),
        title='Top 10 filmes (2017 - 2019)',
        color=df_best.genres.head(10),
        labels={
          'x': '',
          'y': 'Visualizações'
        },
        color_discrete_sequence=px.colors.cyclical.Twilight,
        width=800,
        height=550
    )
fig.update_traces(showlegend=False)

st.write(fig)

msg = st.markdown('Isso pode demorar um pouco... :sweat_smile: (até 5 minutos:disappointed:)')
st.write(msg)

# Top 10 gêneros 2017-2019
df_teset = df_short.copy()

genre = []
for i in range(df_teset.shape[0]):
    for j in df_teset.iloc[i].genres.split(','):
        genre.append(j)

for i in range(len(genre)):
        genre[i] = genre[i].replace(' ', '')

df_genre = pd.DataFrame(genre)
df_genre.drop_duplicates(inplace=True)

count_genre = []
for i in df_genre[0]:
    count_genre.append([i, (np.isin(genre,  i).sum())])

df_count_genre = pd.DataFrame(count_genre)

df_count_genre.rename(columns={0: 'genre', 1: 'count'}, inplace=True)

df_count_genre.sort_values(by='count', ascending=False, inplace=True)

fig = px.bar(
        df_count_genre, 
        x=df_count_genre['genre'].head(10), 
        y=df_count_genre['count'].head(10),
        title='Top 10 gêneros (2017 - 2019)',
        color=df_count_genre['genre'].head(10),
        labels={
          'x': '',
          'y': 'Visualizações'
        },
        color_discrete_sequence=px.colors.diverging.balance, 
        width=800,
        height=450
    )
st.write(fig)

msg.text('')

# Top 10 filmes à partir do gênero escolhido
st.subheader('Top 10 filmes à partir do gênero escolhido')

lista_gen = ['Action', 'Adventure', 'Animation', 'Biography', 'Comedy', 'Crime',
       'Documentary', 'Drama', 'Family', 'Fantasy', 'Film-Noir',
       'History', 'Horror', 'Music', 'Musical', 'Mystery', 'NOTAVAILABLE',
       'News', 'Reality-TV', 'Romance', 'Sci-Fi', 'Short', 'Sport',
       'Talk-Show', 'Thriller', 'War', 'Western']

gen = st.selectbox(
    'Qual gênero deseja ver?',
    (lista_gen)
)

df_test_data = df_best[df_best.genres.str.contains(gen)]
fig = px.bar(
        df_test_data, 
        x=df_test_data.title.head(10),
        y=df_test_data.quantity.head(10),
        title=('Top 10 filmes (2017 - 2019) do gênero '+gen),
        labels={
          'x': '',
          'y': 'Visualizações'
        },
        color_discrete_sequence=px.colors.diverging.PRGn
    )
st.write(fig)

# Top 10 filmes à partir do ano escohido
st.subheader('Top 10 filmes à partir do ano escolhido')

lista_year = [2017, 2018, 2019]

year = st.selectbox(
    'Qual ano deseja ver?',
    (lista_year)
)

df_short_year = df_short[df_short.year == year]

df_best_year = df_short_year.groupby(['title', 'genres']).count().reset_index()
df_best_year.rename(columns={'datetime' : 'quantity'}, inplace=True)
df_best_year.drop(columns=['date', 'time', 'year'], inplace=True)
df_best_year.sort_values('quantity', ascending=False, inplace=True)

fig = px.bar(
        df_best_year, 
        x=df_best_year.title.head(10),
        y=df_best_year.quantity.head(10),
        title=('Top 10 filmes no ano '+str(year)),
        color=df_best_year.genres.head(10),
        labels={
          'x': '',
          'y': 'Visualizações'
        },
        color_discrete_sequence= px.colors.diverging.balance
    )

fig.update_traces(showlegend=False)

st.write(fig)

# Top 10 generos no ano
df_teste_gen = df_short[df_short.year == year].copy()

genre_gen = []
for i in range(df_teste_gen.shape[0]):
    for j in df_teste_gen.iloc[i].genres.split(','):
        genre_gen.append(j)

for i in range(len(genre_gen)):
        genre_gen[i] = genre_gen[i].replace(' ', '')

df_genre_gen = pd.DataFrame(genre_gen)
df_genre_gen.drop_duplicates(inplace=True)

count_genre_gen = []
for i in df_genre_gen[0]:
    count_genre_gen.append([i, (np.isin(genre_gen,  i).sum())])

df_count_genre_gen = pd.DataFrame(count_genre_gen)

df_count_genre_gen.rename(columns={0: 'genre', 1: 'count'}, inplace=True)

df_count_genre_gen.sort_values(by='count', ascending=False, inplace=True)

fig = px.bar(
        df_count_genre_gen, 
        x=df_count_genre_gen['genre'].head(10), 
        y=df_count_genre_gen['count'].head(10),
        title='Top 10 gêneros no ano '+str(year),
        color=df_count_genre_gen['genre'].head(10),
        labels={
          'x': 'Gênero',
          'y': 'Visualizações'
        },
        color_discrete_sequence=px.colors.diverging.balance
    )
st.write(fig)